package com.topicos.proyectospring.controllers;


import com.topicos.proyectospring.models.Client;
import com.topicos.proyectospring.models.Wishlist;
import com.topicos.proyectospring.repositories.ClientRepository;
import com.topicos.proyectospring.services.WishlistService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.ui.Model;


@Controller
@RequestMapping("/wishlist")
public class WishlistController {
    @Autowired
    private WishlistService wishlistService;

    @Autowired
    private ClientRepository clientRepository;

    @GetMapping
    public String viewWishlist(HttpSession session, Model model) {
        Client client = (Client) session.getAttribute("client");
        Wishlist wishlist = wishlistService.getOrCreateWishlist(client);
        model.addAttribute("wishlist", wishlist);
        return "/wishlist/wishlist";
    }

    @PostMapping("/add/{itemId}")
    public String addToWishlist(HttpSession session, @PathVariable Long itemId) {
        Client client = (Client) session.getAttribute("client");
        wishlistService.addItemToWishlist(client.getId(), itemId);
        return "redirect:/wishlist";
    }

    @PostMapping("/remove/{itemId}")
    public String removeFromWishlist(HttpSession session, @PathVariable Long itemId) {
        Client client = (Client) session.getAttribute("client");
        wishlistService.removeItemFromWishlist(client.getId(), itemId);
        return "redirect:/wishlist";
    }
}
